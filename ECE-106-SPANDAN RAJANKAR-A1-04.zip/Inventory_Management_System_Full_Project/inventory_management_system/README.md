# Inventory Management System

A full-stack mini project based on the supplied MDM requirements.

## Technology
- Frontend: HTML, CSS, JavaScript
- Backend: Python Flask
- Database: SQLite
- Communication: REST API + JSON + Fetch API

## Features
- Add product
- View/list products
- Search by product ID, name, or category
- Update product details, stock, and price
- Delete product
- Low-stock alerts
- Dashboard statistics
- Client/server validation
- Duplicate Product ID protection
- No page reload for CRUD operations

## Run

### 1. Create virtual environment
Windows:
```bash
python -m venv venv
venv\Scripts\activate
```

macOS/Linux:
```bash
python3 -m venv venv
source venv/bin/activate
```

### 2. Install
```bash
pip install -r requirements.txt
```

### 3. Start
```bash
python app.py
```

Open:
http://127.0.0.1:5000

The SQLite database is created automatically at:
`instance/inventory.db`
