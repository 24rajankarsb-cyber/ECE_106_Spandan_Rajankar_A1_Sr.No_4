let editMode = false;

const $ = (id) => document.getElementById(id);

function showMessage(text, error=false) {
  $("message").innerHTML = `<div class="${error ? "msg error" : "msg"}">${escapeHtml(text)}</div>`;
  setTimeout(() => $("message").innerHTML = "", 3000);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[ch]));
}

async function loadProducts() {
  const search = $("searchInput").value.trim();
  const response = await fetch(`/api/products?search=${encodeURIComponent(search)}`);
  const products = await response.json();

  $("productTable").innerHTML = products.length ? products.map(p => `
    <tr>
      <td>${escapeHtml(p.product_id)}</td>
      <td>${escapeHtml(p.name)}</td>
      <td>${escapeHtml(p.category)}</td>
      <td>${p.quantity}</td>
      <td>₹${Number(p.price).toFixed(2)}</td>
      <td><span class="badge ${p.quantity <= 5 ? "low" : "ok"}">
        ${p.quantity <= 5 ? "Low Stock" : "Available"}
      </span></td>
      <td>
        <div class="actions">
          <button class="edit" onclick='openEditModal(${JSON.stringify(p)})'>Edit</button>
          <button class="danger" onclick="deleteProduct('${encodeURIComponent(p.product_id)}')">Delete</button>
        </div>
      </td>
    </tr>
  `).join("") : `<tr><td colspan="7" style="text-align:center">No products found.</td></tr>`;

  loadStats();
}

async function loadStats() {
  const response = await fetch("/api/stats");
  const s = await response.json();
  $("totalProducts").textContent = s.total_products;
  $("totalQuantity").textContent = s.total_quantity;
  $("lowStock").textContent = s.low_stock;
  $("totalValue").textContent = `₹${Number(s.total_value).toFixed(2)}`;
}

function openAddModal() {
  editMode = false;
  $("modalTitle").textContent = "Add Product";
  $("productForm").reset();
  $("productId").disabled = false;
  $("productModal").classList.remove("hidden");
}

function openEditModal(p) {
  editMode = true;
  $("modalTitle").textContent = "Update Product";
  $("productId").value = p.product_id;
  $("productId").disabled = true;
  $("name").value = p.name;
  $("category").value = p.category;
  $("quantity").value = p.quantity;
  $("price").value = p.price;
  $("productModal").classList.remove("hidden");
}

function closeModal() {
  $("productModal").classList.add("hidden");
}

$("productForm").addEventListener("submit", async (event) => {
  event.preventDefault();

  const productId = $("productId").value.trim();
  const data = {
    product_id: productId,
    name: $("name").value.trim(),
    category: $("category").value.trim(),
    quantity: Number($("quantity").value),
    price: Number($("price").value)
  };

  if (!data.name || !data.category || !productId) {
    showMessage("Please fill all required fields.", true);
    return;
  }
  if (data.quantity < 0 || data.price < 0) {
    showMessage("Quantity and price cannot be negative.", true);
    return;
  }

  const url = editMode
    ? `/api/products/${encodeURIComponent(productId)}`
    : "/api/products";
  const method = editMode ? "PUT" : "POST";

  const response = await fetch(url, {
    method,
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(data)
  });
  const result = await response.json();

  if (!response.ok) {
    showMessage(result.error || "Operation failed.", true);
    return;
  }

  closeModal();
  showMessage(result.message);
  loadProducts();
});

async function deleteProduct(encodedId) {
  const productId = decodeURIComponent(encodedId);
  if (!confirm(`Delete product ${productId}?`)) return;

  const response = await fetch(`/api/products/${encodeURIComponent(productId)}`, {
    method: "DELETE"
  });
  const result = await response.json();

  if (!response.ok) {
    showMessage(result.error || "Delete failed.", true);
    return;
  }
  showMessage(result.message);
  loadProducts();
}

loadProducts();
