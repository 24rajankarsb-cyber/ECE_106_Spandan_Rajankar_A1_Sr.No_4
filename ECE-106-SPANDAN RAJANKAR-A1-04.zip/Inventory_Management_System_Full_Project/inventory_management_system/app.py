from flask import Flask, request, jsonify, render_template
import sqlite3
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "instance" / "inventory.db"

app = Flask(__name__)

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    DB_PATH.parent.mkdir(exist_ok=True)
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            quantity INTEGER NOT NULL CHECK(quantity >= 0),
            price REAL NOT NULL CHECK(price >= 0),
            created_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

def row_to_dict(row):
    return dict(row)

@app.route("/")
def index():
    return render_template("index.html")

@app.get("/api/products")
def get_products():
    search = request.args.get("search", "").strip()
    conn = get_db()
    if search:
        rows = conn.execute("""
            SELECT * FROM products
            WHERE product_id LIKE ?
               OR name LIKE ?
               OR category LIKE ?
            ORDER BY id DESC
        """, (f"%{search}%", f"%{search}%", f"%{search}%")).fetchall()
    else:
        rows = conn.execute("SELECT * FROM products ORDER BY id DESC").fetchall()
    conn.close()
    return jsonify([row_to_dict(row) for row in rows])

@app.get("/api/products/<product_id>")
def get_product(product_id):
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM products WHERE product_id = ?", (product_id,)
    ).fetchone()
    conn.close()
    if not row:
        return jsonify({"error": "Product not found"}), 404
    return jsonify(row_to_dict(row))

@app.post("/api/products")
def add_product():
    data = request.get_json(silent=True) or {}
    product_id = str(data.get("product_id", "")).strip()
    name = str(data.get("name", "")).strip()
    category = str(data.get("category", "")).strip()

    if not product_id or not name or not category:
        return jsonify({"error": "Product ID, name and category are required."}), 400

    try:
        quantity = int(data.get("quantity"))
        price = float(data.get("price"))
    except (TypeError, ValueError):
        return jsonify({"error": "Quantity must be an integer and price must be a number."}), 400

    if quantity < 0:
        return jsonify({"error": "Quantity cannot be negative."}), 400
    if price < 0:
        return jsonify({"error": "Price cannot be negative."}), 400

    conn = get_db()
    try:
        conn.execute("""
            INSERT INTO products
            (product_id, name, category, quantity, price, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (product_id, name, category, quantity, price,
              datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({"error": "Product ID already exists."}), 409
    conn.close()
    return jsonify({"message": "Product added successfully."}), 201

@app.put("/api/products/<product_id>")
def update_product(product_id):
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    category = str(data.get("category", "")).strip()

    if not name or not category:
        return jsonify({"error": "Name and category are required."}), 400

    try:
        quantity = int(data.get("quantity"))
        price = float(data.get("price"))
    except (TypeError, ValueError):
        return jsonify({"error": "Quantity must be an integer and price must be a number."}), 400

    if quantity < 0:
        return jsonify({"error": "Quantity cannot be negative."}), 400
    if price < 0:
        return jsonify({"error": "Price cannot be negative."}), 400

    conn = get_db()
    cur = conn.execute("""
        UPDATE products
        SET name = ?, category = ?, quantity = ?, price = ?
        WHERE product_id = ?
    """, (name, category, quantity, price, product_id))
    conn.commit()
    conn.close()

    if cur.rowcount == 0:
        return jsonify({"error": "Product not found."}), 404
    return jsonify({"message": "Product updated successfully."})

@app.delete("/api/products/<product_id>")
def delete_product(product_id):
    conn = get_db()
    cur = conn.execute(
        "DELETE FROM products WHERE product_id = ?", (product_id,)
    )
    conn.commit()
    conn.close()

    if cur.rowcount == 0:
        return jsonify({"error": "Product not found."}), 404
    return jsonify({"message": "Product deleted successfully."})

@app.get("/api/stats")
def stats():
    conn = get_db()
    total_products = conn.execute("SELECT COUNT(*) AS c FROM products").fetchone()["c"]
    total_quantity = conn.execute("SELECT COALESCE(SUM(quantity),0) AS s FROM products").fetchone()["s"]
    low_stock = conn.execute("SELECT COUNT(*) AS c FROM products WHERE quantity <= 5").fetchone()["c"]
    total_value = conn.execute("SELECT COALESCE(SUM(quantity * price),0) AS v FROM products").fetchone()["v"]
    conn.close()
    return jsonify({
        "total_products": total_products,
        "total_quantity": total_quantity,
        "low_stock": low_stock,
        "total_value": round(total_value, 2)
    })

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
